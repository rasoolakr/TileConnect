package com.example.anjaniimport.controller;

import com.example.anjaniimport.dto.ImportRequest;
import com.example.anjaniimport.dto.ProductRecord;
import com.example.anjaniimport.service.AnjaniScraperService;
import com.example.anjaniimport.service.CsvService;
import com.example.anjaniimport.service.PushService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/anjani")
public class CatalogController {
	private final AnjaniScraperService scraper;
	private final CsvService csv;

	public CatalogController(AnjaniScraperService scraper, CsvService csv, PushService ignored) {
		this.scraper = scraper;
		this.csv = csv;
	}

	@PostMapping("/fetch")
	public List<ProductRecord> fetch(@RequestBody(required = false) ImportRequest request) throws Exception {
		return scraper.fetch(request == null ? new ImportRequest(null, null, null, null, 50) : request);
	}

	@PostMapping(value = "/csv", produces = "text/csv")
	public ResponseEntity<byte[]> csv(@RequestBody(required = false) ImportRequest request) throws Exception {
		List<ProductRecord> p = scraper
				.fetch(request == null ? new ImportRequest(null, null, null, null, 50) : request);
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=anjani-products.csv")
				.contentType(MediaType.parseMediaType("text/csv")).body(csv.toCsv(p));
	}

	@GetMapping("/health")
	public String health() {
		return "OK";
	}
}

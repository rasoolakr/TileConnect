//package com.example.anjaniimport.service;
//
//import com.example.anjaniimport.dto.ImportRequest;
//import com.example.anjaniimport.dto.ProductRecord;
//import org.jsoup.Jsoup;
//import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
//import org.jsoup.select.Elements;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//
//import java.net.URI;
//import java.util.*;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//@Service
//public class AnjaniScraperService {
//    private static final Pattern CODE_PREFIX = Pattern.compile("^(\\d{3,6})\\s+.*$");
//    private static final Pattern SIZE = Pattern.compile("(?i)(\\d{2,4}x\\d{2,4}(?:x\\d{2,4})?mm(?:\\s*\\([^)]*\\))?)");
//    private final String baseUrl;
//    private final String userAgent;
//    private final long delayMs;
//    private final int configuredMax;
//
//    public AnjaniScraperService(@Value("${anjani.base-url}") String baseUrl,
//                                @Value("${anjani.user-agent}") String userAgent,
//                                @Value("${anjani.request-delay-ms:150}") long delayMs,
//                                @Value("${anjani.max-products:200}") int configuredMax) {
//        this.baseUrl = baseUrl; this.userAgent = userAgent; this.delayMs = delayMs; this.configuredMax = configuredMax;
//    }
//
//    public List<ProductRecord> fetch(ImportRequest request) throws Exception {
//        String listUrl = buildListUrl(request);
//        Document list = Jsoup.connect(listUrl).userAgent(userAgent).timeout(30000).get();
//        LinkedHashMap<String, ProductRecord> result = new LinkedHashMap<>();
//        for (Element link : findProductLinks(list)) {
//            if (result.size() >= Math.min(configuredMax, request.maxProducts() == null ? configuredMax : request.maxProducts())) break;
//            String detailUrl = absolute(link.attr("href"));
//            String fallbackName = clean(link.text());
//            try {
//                Document detail = Jsoup.connect(detailUrl).userAgent(userAgent).timeout(30000).get();
//                ProductRecord p = parseDetail(detail, detailUrl, fallbackName, listUrl);
//                if (matches(p, request)) result.put(p.importKey(), p);
//            } catch (Exception ignored) { /* one bad product must not abort the whole import */ }
//            sleep();
//        }
//        return new ArrayList<>(result.values());
//    }
//
//    private Elements findProductLinks(Document doc) {
//        Elements candidates = doc.select("a[href*='product-detail.php']");
//        if (!candidates.isEmpty()) return candidates;
//        return doc.select("a");
//    }
//
//    private ProductRecord parseDetail(Document doc, String detailUrl, String fallbackName, String sourceUrl) {
//        String name = firstNonBlank(
//                doc.select("h1").stream().map(Element::text).filter(s -> !s.isBlank()).findFirst().orElse(""),
//                doc.select("h2").stream().map(Element::text).filter(s -> !s.isBlank()).findFirst().orElse(""),
//                fallbackName);
//        String text = clean(doc.body().text());
//        String collection = labelValue(text, "Collection");
//        String size = labelValue(text, "Size");
//        String finish = labelValue(text, "Finish");
//        String color = labelValue(text, "Color");
//        String application = labelValue(text, "Application");
//        if (size.isBlank()) { Matcher m = SIZE.matcher(text); if (m.find()) size = m.group(1); }
//        String imageUrl = extractBestImage(doc, name);
//        String code = extractCode(name);
//        String key = code.isBlank() ? slug(name) + "|" + size : code + "|" + size;
//        return new ProductRecord("ANJANI_TEK", code, name, collection, size, finish, color, application,
//                detailUrl, imageUrl, sourceUrl, key);
//    }
//
//    private String labelValue(String text, String label) {
//        Pattern p = Pattern.compile("(?i)" + Pattern.quote(label) + "\\s*[:|]?\\s*([^|]{1,120}?)(?=\\s+(?:Collection|Size|Finish|Color|Application)\\b|$)");
//        Matcher m = p.matcher(text); return m.find() ? clean(m.group(1)) : "";
//    }
//
//    private String extractBestImage(Document doc, String name) {
//        String normalized = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
//        for (Element img : doc.select("img[src]")) {
//            String alt = clean(img.attr("alt")).toLowerCase(Locale.ROOT);
//            String src = img.absUrl("src");
//            if (!src.isBlank() && (!normalized.isBlank() && alt.contains(normalized.split(" ")[0]))) return src;
//        }
//        for (Element img : doc.select("img[src]")) {
//            String src = img.absUrl("src"); if (!src.isBlank()) return src;
//        }
//        return "";
//    }
//
//    private boolean matches(ProductRecord p, ImportRequest r) {
//        return contains(r.collection(), p.collection()) && contains(r.size(), p.size()) && contains(r.finish(), p.finish()) && contains(r.color(), p.color());
//    }
//    private boolean contains(String filter, String value) { return filter == null || filter.isBlank() || value.toLowerCase(Locale.ROOT).contains(filter.toLowerCase(Locale.ROOT)); }
//    private String buildListUrl(ImportRequest r) {
//        StringBuilder u = new StringBuilder(baseUrl).append("/product-list.php?");
//        boolean first = true;
//        if (r.collection()!=null&&!r.collection().isBlank()) { u.append("collection=").append(java.net.URLEncoder.encode(r.collection(), java.nio.charset.StandardCharsets.UTF_8)); first=false; }
//        if (r.size()!=null&&!r.size().isBlank()) { if(!first)u.append('&'); u.append("size=").append(java.net.URLEncoder.encode(r.size(), java.nio.charset.StandardCharsets.UTF_8)); first=false; }
//        if (r.finish()!=null&&!r.finish().isBlank()) { if(!first)u.append('&'); u.append("finish=").append(java.net.URLEncoder.encode(r.finish(), java.nio.charset.StandardCharsets.UTF_8)); first=false; }
//        if (r.color()!=null&&!r.color().isBlank()) { if(!first)u.append('&'); u.append("color=").append(java.net.URLEncoder.encode(r.color(), java.nio.charset.StandardCharsets.UTF_8)); }
//        return u.toString();
//    }
//    private String absolute(String href) { try { return URI.create(baseUrl).resolve(href).toString(); } catch(Exception e){return href;} }
//    private String extractCode(String name) { Matcher m=CODE_PREFIX.matcher(name); return m.matches()?m.group(1):""; }
//    private String slug(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+","-").replaceAll("^-|-$",""); }
//    private String clean(String s) { return s == null ? "" : s.replaceAll("\\s+"," ").trim(); }
//    private String firstNonBlank(String... values) { for(String v:values) if(v!=null&&!v.isBlank()) return clean(v); return ""; }
//    private void sleep() { if(delayMs<=0)return; try{Thread.sleep(delayMs);}catch(InterruptedException e){Thread.currentThread().interrupt();} }
//}

package com.example.anjaniimport.service;

import com.example.anjaniimport.dto.ImportRequest;
import com.example.anjaniimport.dto.ProductRecord;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class AnjaniScraperService {

	private static final Pattern CODE_PREFIX = Pattern.compile("^(\\d{3,6})\\s+.*$");

	private static final Pattern SIZE_PATTERN = Pattern
			.compile("(?i)(\\d{2,4}\\s*[xX]\\s*\\d{2,4}(?:\\s*[xX]\\s*\\d{2,4})?\\s*mm)");

	private final String baseUrl;
	private final String userAgent;
	private final long delayMs;
	private final int configuredMax;

	public AnjaniScraperService(@Value("${anjani.base-url}") String baseUrl,
			@Value("${anjani.user-agent}") String userAgent, @Value("${anjani.request-delay-ms:300}") long delayMs,
			@Value("${anjani.max-products:200}") int configuredMax) {

		this.baseUrl = baseUrl;
		this.userAgent = userAgent;
		this.delayMs = delayMs;
		this.configuredMax = configuredMax;
	}

	public List<ProductRecord> fetch(ImportRequest request) throws Exception {

	    String listUrl = buildListUrl(request);

	    System.out.println("========================================");
	    System.out.println("ANJANI LIST URL: " + listUrl);
	    System.out.println("========================================");

	    Document list = Jsoup.connect(listUrl)
	            .userAgent(userAgent)
	            .timeout(30000)
	            .get();

	    LinkedHashMap<String, ProductRecord> result = new LinkedHashMap<>();

	    Elements productLinks = findProductLinks(list);

	    System.out.println("Product links found: " + productLinks.size());

	    int maxProducts = Math.min(
	            configuredMax,
	            request.maxProducts() == null
	                    ? configuredMax
	                    : request.maxProducts()
	    );

	    for (Element link : productLinks) {

	        if (result.size() >= maxProducts) {
	            break;
	        }

	        String href = link.attr("href");

	        System.out.println("RAW HREF: " + href);

	        if (href == null || href.isBlank()) {
	            continue;
	        }

	        String detailUrl = absolute(href);

	        if (detailUrl.isBlank()) {
	            System.out.println("Skipping invalid URL: " + href);
	            continue;
	        }

	        // Validate URL
	        if (!detailUrl.contains("product-detail.php")) {
	            System.out.println("Skipping non-product URL: " + detailUrl);
	            continue;
	        }

	        System.out.println("PROCESSING: " + detailUrl);

	        String fallbackName = clean(link.text());

	        try {

	            Document detail = Jsoup.connect(detailUrl)
	                    .userAgent(userAgent)
	                    .timeout(30000)
	                    .get();

	            ProductRecord p =
	                    parseDetail(
	                            detail,
	                            detailUrl,
	                            fallbackName,
	                            listUrl
	                    );

	            if (matches(p, request)) {
	                result.put(p.importKey(), p);
	                System.out.println("MATCHED: " + p);
	            } else {
	                System.out.println("FILTERED OUT: " + fallbackName);
	            }

	        } catch (Exception e) {

	            System.err.println("FAILED TO SCRAPE: " + detailUrl);
	            System.err.println("Reason: " + e.getMessage());

	        }

	        sleep();
	    }

	    System.out.println("========================================");
	    System.out.println("TOTAL PRODUCTS RETURNED: " + result.size());
	    System.out.println("========================================");

	    return new ArrayList<>(result.values());
	}

	/**
	 * Fetch the normal product listing page.
	 *
	 * We intentionally do not use the request filters here.
	 */
	private String buildListUrl(ImportRequest r) {

	    StringBuilder u = new StringBuilder(baseUrl);

	    // Make sure there is exactly one /
	    if (!baseUrl.endsWith("/")) {
	        u.append("/");
	    }

	    u.append("product-list.php");

	    boolean first = true;

	    if (r.collection() != null && !r.collection().isBlank()) {
	        u.append(first ? "?" : "&");
	        u.append("collection=")
	         .append(URLEncoder.encode(
	                 r.collection(),
	                 StandardCharsets.UTF_8
	         ));
	        first = false;
	    }

	    if (r.size() != null && !r.size().isBlank()) {
	        u.append(first ? "?" : "&");
	        u.append("size=")
	         .append(URLEncoder.encode(
	                 r.size(),
	                 StandardCharsets.UTF_8
	         ));
	        first = false;
	    }

	    if (r.finish() != null && !r.finish().isBlank()) {
	        u.append(first ? "?" : "&");
	        u.append("finish=")
	         .append(URLEncoder.encode(
	                 r.finish(),
	                 StandardCharsets.UTF_8
	         ));
	        first = false;
	    }

	    if (r.color() != null && !r.color().isBlank()) {
	        u.append(first ? "?" : "&");
	        u.append("color=")
	         .append(URLEncoder.encode(
	                 r.color(),
	                 StandardCharsets.UTF_8
	         ));
	    }

	    return u.toString();
	}

	/**
	 * Find product-detail.php links.
	 */
	private Elements findProductLinks(Document doc) {

	    Elements candidates =
	            doc.select("a[href*='product-detail.php']");

	    System.out.println(
	            "Product detail links found: "
	                    + candidates.size()
	    );

	    return candidates;
	}

	/**
	 * Parse a product detail page.
	 */
	private ProductRecord parseDetail(Document doc, String detailUrl, String fallbackName, String sourceUrl) {

		String name = extractProductName(doc, fallbackName);

		String bodyText = clean(doc.body().text());

		/*
		 * First try structured HTML.
		 */
		String collection = findValueByLabel(doc, "Collection");

		String size = findValueByLabel(doc, "Size");

		String finish = findValueByLabel(doc, "Finish");

		String color = findValueByLabel(doc, "Color");

		String application = findValueByLabel(doc, "Application");

		/*
		 * Fallback to body text.
		 */
		if (collection.isBlank()) {
			collection = labelValue(bodyText, "Collection");
		}

		if (size.isBlank()) {
			size = labelValue(bodyText, "Size");
		}

		if (finish.isBlank()) {
			finish = labelValue(bodyText, "Finish");
		}

		if (color.isBlank()) {
			color = labelValue(bodyText, "Color");
		}

		if (application.isBlank()) {
			application = labelValue(bodyText, "Application");
		}

		/*
		 * Last fallback for size.
		 */
		if (size.isBlank()) {

			Matcher matcher = SIZE_PATTERN.matcher(bodyText);

			if (matcher.find()) {

				size = clean(matcher.group(1));
			}
		}

		String imageUrl = extractBestImage(doc, name);

		String code = extractCode(name);

		/*
		 * Sometimes product code is available directly in the URL.
		 */
		if (code.isBlank()) {

			code = extractCodeFromUrl(detailUrl);
		}

		String importKey;

		if (!code.isBlank()) {

			importKey = code + "|" + normalize(size);

		} else {

			importKey = slug(name) + "|" + normalize(size);
		}

		return new ProductRecord("ANJANI_TEK", code, name, collection, size, finish, color, application, detailUrl,
				imageUrl, sourceUrl, importKey);
	}

	/**
	 * Extract product name.
	 */
	private String extractProductName(Document doc, String fallbackName) {

		/*
		 * Try H1.
		 */
		Element h1 = doc.selectFirst("h1");

		if (h1 != null && !h1.text().isBlank()) {

			return clean(h1.text());
		}

		/*
		 * Try H2.
		 */
		Element h2 = doc.selectFirst("h2");

		if (h2 != null && !h2.text().isBlank()) {

			return clean(h2.text());
		}

		/*
		 * Try title.
		 */
		if (!doc.title().isBlank()) {

			String title = clean(doc.title());

			if (!title.isBlank()) {

				return title;
			}
		}

		return clean(fallbackName);
	}

	/**
	 * Find values from structured HTML.
	 *
	 * Supports:
	 *
	 * <tr>
	 * <td>Collection</td>
	 * <td>GVT Collections</td>
	 * </tr>
	 *
	 * and similar structures.
	 */
	private String findValueByLabel(Document doc, String label) {

		/*
		 * Table rows.
		 */
		for (Element row : doc.select("tr")) {

			Elements cells = row.select("th, td");

			if (cells.size() >= 2) {

				String first = clean(cells.get(0).text());

				if (first.equalsIgnoreCase(label)) {

					return clean(cells.get(cells.size() - 1).text());
				}
			}
		}

		/*
		 * Generic label/value structures.
		 */
		for (Element element : doc.select("*")) {

			String text = clean(element.text());

			if (!text.equalsIgnoreCase(label)) {
				continue;
			}

			/*
			 * Look at next sibling.
			 */
			Element sibling = element.nextElementSibling();

			if (sibling != null) {

				String value = clean(sibling.text());

				if (!value.isBlank() && !value.equalsIgnoreCase(label)) {

					return value;
				}
			}

			/*
			 * Look at parent's children.
			 */
			Element parent = element.parent();

			if (parent != null) {

				Elements children = parent.children();

				int index = children.indexOf(element);

				if (index >= 0 && index + 1 < children.size()) {

					String value = clean(children.get(index + 1).text());

					if (!value.isBlank() && !value.equalsIgnoreCase(label)) {

						return value;
					}
				}
			}
		}

		return "";
	}

	/**
	 * Fallback parser for plain body text.
	 */
	private String labelValue(String text, String label) {

		String[] labels = { "Collection", "Size", "Finish", "Color", "Application" };

		StringBuilder nextLabels = new StringBuilder();

		for (String current : labels) {

			if (!current.equalsIgnoreCase(label)) {

				if (nextLabels.length() > 0) {
					nextLabels.append("|");
				}

				nextLabels.append(Pattern.quote(current));
			}
		}

		String regex = "(?i)" + Pattern.quote(label) + "\\s*[:|]?\\s*" + "(.{1,120}?)" + "(?=\\s+(?:" + nextLabels
				+ ")\\b|$)";

		Matcher matcher = Pattern.compile(regex).matcher(text);

		if (matcher.find()) {

			return clean(matcher.group(1));
		}

		return "";
	}

	/**
	 * Extract product image.
	 */
	private String extractBestImage(Document doc, String productName) {

	    String normalizedName = normalize(productName);

	    /*
	     * 1. FIRST PRIORITY:
	     * Look specifically for Anjani product images.
	     *
	     * Example:
	     * uploads/products/1732712395.-black-6103.jpg
	     */
	    for (Element img : doc.select("img")) {

	        String src = getImageSource(img);

	        if (src.isBlank()) {
	            continue;
	        }

	        String lowerSrc = src.toLowerCase(Locale.ROOT);

	        if (lowerSrc.contains("/uploads/products/")) {

	            System.out.println("PRODUCT IMAGE FOUND: " + src);

	            return src;
	        }
	    }

	    /*
	     * 2. SECOND PRIORITY:
	     * Try product image containers.
	     */
	    Elements productImages = doc.select(
	            ".product img, " +
	            ".product-detail img, " +
	            ".product-details img, " +
	            ".single-product img, " +
	            ".item img"
	    );

	    for (Element img : productImages) {

	        String src = getImageSource(img);

	        if (src.isBlank()) {
	            continue;
	        }

	        String lowerSrc = src.toLowerCase(Locale.ROOT);

	        // Don't return logos/icons
	        if (isInvalidImage(lowerSrc)) {
	            continue;
	        }

	        System.out.println("PRODUCT CONTAINER IMAGE FOUND: " + src);

	        return src;
	    }

	    /*
	     * 3. THIRD PRIORITY:
	     * Try image whose alt/name matches product.
	     */
	    for (Element img : doc.select("img")) {

	        String src = getImageSource(img);

	        if (src.isBlank()) {
	            continue;
	        }

	        String lowerSrc = src.toLowerCase(Locale.ROOT);

	        if (isInvalidImage(lowerSrc)) {
	            continue;
	        }

	        String alt = normalize(img.attr("alt"));

	        if (!alt.isBlank()
	                && !normalizedName.isBlank()
	                && (alt.contains(normalizedName)
	                || normalizedName.contains(alt))) {

	            System.out.println("ALT MATCHED IMAGE: " + src);

	            return src;
	        }
	    }

	    /*
	     * 4. FINAL FALLBACK:
	     * Find any non-logo image.
	     */
	    for (Element img : doc.select("img")) {

	        String src = getImageSource(img);

	        if (src.isBlank()) {
	            continue;
	        }

	        String lowerSrc = src.toLowerCase(Locale.ROOT);

	        if (!isInvalidImage(lowerSrc)) {

	            System.out.println("FALLBACK IMAGE: " + src);

	            return src;
	        }
	    }

	    return "";
	}
	
	private boolean isInvalidImage(String src) {

	    if (src == null || src.isBlank()) {
	        return true;
	    }

	    String value = src.toLowerCase(Locale.ROOT);

	    return value.contains("/logo/")
	            || value.contains("logo.")
	            || value.contains("/favicon")
	            || value.contains("favicon.")
	            || value.contains("/icon/")
	            || value.contains("icon.")
	            || value.contains("facebook")
	            || value.contains("instagram")
	            || value.contains("twitter")
	            || value.contains("linkedin");
	}

//	private String getImageSource(Element img) {
//
//		String src = img.absUrl("src");
//
//		if (!src.isBlank()) {
//			return src;
//		}
//
//		src = img.absUrl("data-src");
//
//		if (!src.isBlank()) {
//			return src;
//		}
//
//		src = img.absUrl("data-lazy-src");
//
//		return src;
//	}
	private String getImageSource(Element img) {

	    String[] attributes = {
	            "src",
	            "data-src",
	            "data-lazy-src",
	            "data-original",
	            "data-image"
	    };

	    for (String attribute : attributes) {

	        String value = img.attr(attribute);

	        if (value == null || value.isBlank()) {
	            continue;
	        }

	        String absoluteUrl = img.absUrl(attribute);

	        if (!absoluteUrl.isBlank()) {
	            return absoluteUrl;
	        }
	    }

	    return "";
	}

	/**
	 * Apply user-requested filters locally.
	 */
	private boolean matches(ProductRecord product, ImportRequest request) {

		return matchesValue(request.collection(), product.collection()) && matchesValue(request.size(), product.size())
				&& matchesValue(request.finish(), product.finish()) && matchesValue(request.color(), product.color());
	}

	private boolean matchesValue(String filter, String actualValue) {

		/*
		 * No filter supplied.
		 */
		if (filter == null || filter.isBlank()) {

			return true;
		}

		if (actualValue == null || actualValue.isBlank()) {

			return false;
		}

		return normalize(actualValue).contains(normalize(filter));
	}

	private String extractCode(String name) {

		if (name == null || name.isBlank()) {

			return "";
		}

		Matcher matcher = CODE_PREFIX.matcher(clean(name));

		if (matcher.matches()) {

			return matcher.group(1);
		}

		return "";
	}

	/**
	 * Example:
	 *
	 * /product-detail.php?id=6103-AMAZON-BLACK&size=3
	 *
	 * returns 6103.
	 */
	private String extractCodeFromUrl(String url) {

		if (url == null || url.isBlank()) {

			return "";
		}

		Pattern pattern = Pattern.compile("[?&]id=(\\d{3,6})");

		Matcher matcher = pattern.matcher(url);

		if (matcher.find()) {

			return matcher.group(1);
		}

		return "";
	}

	private String absolute(String href) {

	    if (href == null || href.isBlank()) {
	        return "";
	    }

	    href = href.trim();

	    try {

	        // Already an absolute URL
	        if (href.startsWith("http://") ||
	            href.startsWith("https://")) {
	            return href;
	        }

	        String normalizedBase =
	                baseUrl.endsWith("/")
	                        ? baseUrl
	                        : baseUrl + "/";

	        String normalizedHref =
	                href.startsWith("/")
	                        ? href.substring(1)
	                        : href;

	        return URI.create(normalizedBase)
	                .resolve(normalizedHref)
	                .toString();

	    } catch (Exception e) {

	        System.err.println(
	                "Unable to build absolute URL. href=" + href
	        );

	        return "";
	    }
	}

	private String normalize(String value) {

		if (value == null) {
			return "";
		}

		return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
	}

	private String slug(String value) {

		return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
	}

	private String clean(String value) {

		if (value == null) {
			return "";
		}

		return value.replaceAll("\\s+", " ").trim();
	}

	private void sleep() {

		if (delayMs <= 0) {
			return;
		}

		try {

			Thread.sleep(delayMs);

		} catch (InterruptedException e) {

			Thread.currentThread().interrupt();
		}
	}
}

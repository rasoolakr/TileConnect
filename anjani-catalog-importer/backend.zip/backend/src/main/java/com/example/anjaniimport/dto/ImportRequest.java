package com.example.anjaniimport.dto;

public record ImportRequest(String collection, String size, String finish, String color, Integer maxProducts) {}

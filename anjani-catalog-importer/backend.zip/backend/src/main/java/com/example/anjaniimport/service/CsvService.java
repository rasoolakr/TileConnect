package com.example.anjaniimport.service;

import com.example.anjaniimport.dto.ProductRecord;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CsvService {
    public byte[] toCsv(List<ProductRecord> products) {
        StringBuilder b = new StringBuilder();
        b.append("supplierName,supplierProductCode,name,collection,size,finish,color,application,detailUrl,imageUrl,sourceUrl,importKey\n");
        for (ProductRecord p : products) {
            b.append(row(p.supplierName())).append(',').append(row(p.supplierProductCode())).append(',').append(row(p.name())).append(',')
             .append(row(p.collection())).append(',').append(row(p.size())).append(',').append(row(p.finish())).append(',').append(row(p.color())).append(',')
             .append(row(p.application())).append(',').append(row(p.detailUrl())).append(',').append(row(p.imageUrl())).append(',').append(row(p.sourceUrl())).append(',').append(row(p.importKey())).append('\n');
        }
        return b.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
    }
    private String row(String s) { String v=s==null?"":s.replace("\"","\"\""); return "\""+v+"\""; }
}
